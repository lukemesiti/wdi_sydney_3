var carousel = document.getElementById('carousel');
var next = document.getElementById('next');
var previous = document.getElementById('previous');

carousel.style.marginLeft = 0;

// Slides the images to the left or goes back to the first image if it has reached the end
function toLeft(){
}


// Slides the images to the right or goes back to the last image if it has reached the end
function toRight(){
}

//Hook up the next and previous buttons to call the toLeft and toRight functions